// Pie Chart: Category Distribution
const pieCtx = document.getElementById('pieChart').getContext('2d');
new Chart(pieCtx, {
  type: 'pie',
  data: {
    labels: ['Electronics', 'Furniture', 'Grocery', 'Clothing', 'Stationery'],
    datasets: [{
      label: 'Inventory Categories',
      data: [25, 15, 30, 20, 10],
      backgroundColor: ['#3498db', '#2ecc71', '#f39c12', '#e74c3c', '#9b59b6'],
    }]
  }
});

// Bar Chart: Stock Quantities
const barCtx = document.getElementById('barChart').getContext('2d');
new Chart(barCtx, {
  type: 'bar',
  data: {
    labels: ['Laptops', 'Chairs', 'Milk', 'T-Shirts', 'Pens'],
    datasets: [{
      label: 'Stock Available',
      data: [120, 85, 200, 150, 400],
      backgroundColor: '#2ecc71',
      borderColor: '#27ae60',
      borderWidth: 1
    }]
  },
  options: {
    scales: {
      y: {
        beginAtZero: true
      }
    }
  }
});
